
#pragma once
#include "../src/lib/defines.hpp"
#include "../src/lib/appEnv.hpp"
#include "../src/lib/random.hpp"
#include <ctime>


namespace common {

enum Window {
  WIDTH  = 512,
  HEIGHT = 512,
};

}
